﻿namespace HouseRentingSystem.Services.Users.Models
{
    public class UserServiceModel
    {
        public string Email { get; init; }

        public string FullName { get; init; }

        public string PhoneNumber { get; init; }
    }
}
