﻿namespace Eventmi.Infrastructure
{
    public  class Connection
    {
        public const string ConnectionString = @".;Database=Eventmi;Integrated Security=True;Encrypt=False";
    }
}
