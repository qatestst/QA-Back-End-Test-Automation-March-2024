﻿using EFCoreArchitecture.Infrastructure.Data.Common;

namespace Eventmi.Infrastructure.Data.Repositories
{
    public interface IEventmiRepository : IRepository
    {
    }
}
