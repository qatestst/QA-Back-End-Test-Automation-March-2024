﻿namespace Eventmi.Infrastructure
{
    public static class GlobalConstants
    {
        public const int EventNameMaxLength = 50;
    }
}
