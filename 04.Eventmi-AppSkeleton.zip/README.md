# Eventmi

ASP.NET MVC Project for Workshop 1 from [Entity Framework Core Course @ SoftUni](https://github.com/udarensamolet/SoftUni-5-Entity-Framework-Core).

Implements the Repository-Service Pattern with a hint of Unit of Work Pattern.

